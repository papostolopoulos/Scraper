"""Console script helpers (empty module to mark package)."""
