"""JobMiner package initialization."""
